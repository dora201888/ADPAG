options(width=2000) 
argv = commandArgs(TRUE);  
print(argv) 
print(paste("length=",length(argv),sep=""))  
f0<-as.numeric(argv[1]) 
f1<-as.numeric(argv[2]) 
mergeVar<-as.numeric(argv[3])  
print(c("f0,f1=",f0,f1,mergeVar))
#################################################
library(postGGIR)
studyname <- "Example"
bindir <- ""
outputdir <- "/data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/GGIR/output_binfile"
writedir <- "data"
epochIn <- 5
epochOut <- 60
currentdir <- "/data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/afterGGIR"
#################################################
setwd(currentdir)
ggir.datatransform(outputdir=outputdir,subdir=writedir,studyname=studyname, numericID=FALSE,sortByid="filename",f0,f1,epochIn=epochIn,epochOut=epochOut,mergeVar=mergeVar)
